# Databricks notebook source
# MAGIC %md
# MAGIC  drop "page”, "per_page", "total", "total_pages" and complete block of support. 

# COMMAND ----------

import requests
import json

# COMMAND ----------

api_url= "https://reqres.in/api/users"

# COMMAND ----------

page = 2
all_data = []

# COMMAND ----------

response = requests.get(api_url, params={"page": page})
result = response.json()
if result:
    data = result.get('data',[])
    all_data.extend(data)
    page += 1

# COMMAND ----------

for user in all_data:
    print(user)

# COMMAND ----------

# MAGIC %md
# MAGIC Read the data frame with a custom schema 

# COMMAND ----------

from pyspark.sql.types import StringType, IntegerType, StructField, StructType
schema = StructType([
    StructField("id", IntegerType(), True),
    StructField("email", StringType(), True),
    StructField("first_name", StringType(), True),
    StructField("last_name", StringType(), True),
    StructField("avatar", StringType(), True)
])
df = spark.createDataFrame(all_data, schema)
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Derive a new column from email as site_address with values(reqres.in) 

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

df = df.withColumn("site_address", lit("reqres.in")) \
       .withColumn("load_date", current_date())
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Write the data frame to location in DBFS as /db_name /table_name with Db_name as site_info and table_name as person_info with delta format and overwrite mode. 

# COMMAND ----------

df.write.format("delta").mode("overwrite").save("/Volumes/databricks_assignment/site_info/person_info")

# COMMAND ----------

df2 = spark.read.format("delta").load("/Volumes/databricks_assignment/site_info/person_info")
display(df2)