# Databricks notebook source
def read_file(file_path, file_format, **options):
    file_format = file_format.lower()

    reader = spark.read.format(file_format)

    for key, value in options.items():
        reader = reader.option(key, value)

    return reader.load(file_path)