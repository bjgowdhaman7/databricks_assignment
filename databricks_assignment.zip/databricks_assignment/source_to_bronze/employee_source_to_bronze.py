# Databricks notebook source
# MAGIC %run ./utils 

# COMMAND ----------

country_csv_file = '/Volumes/databricks_assignment/documents/csvfiles/Country-Q1.csv'
department_csv_file = '/Volumes/databricks_assignment/documents/csvfiles/Department-Q1.csv'
employee_csv_file ='/Volumes/databricks_assignment/documents/csvfiles/Employee-Q1.csv'

file_format = 'csv'

# COMMAND ----------

country_df = read_file(country_csv_file,file_format, header='true', inferschema = 'true')

department_df = read_file(department_csv_file,file_format, header='true', inferschema = 'true')

employee_df = read_file(employee_csv_file,file_format, header='true', inferschema = 'true')

# COMMAND ----------

country_df.display()
department_df.display()
employee_df.display()