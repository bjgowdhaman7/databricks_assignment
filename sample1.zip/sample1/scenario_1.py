# Databricks notebook source
# MAGIC %md
# MAGIC Q1. while ingesting customer data from an external source, you notice duplicate entries. how would you remove duplicates and retain only the latest based on a timestamp columns?

# COMMAND ----------

data = [
    ("101", "2023-12-01",100),
    ("101", "2023-12-02",150),
    ("102", "2023-12-01",200),
    ("102", "2023-12-02",550)
]
df = spark.createDataFrame(data, ["id", "date", "value"])
df.display()

# COMMAND ----------

from pyspark.sql.window import Window
import pyspark.sql.functions as F

df.withColumn("date", df["date"].cast("date"))
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC method-1 - using window function 

# COMMAND ----------

window_spec = Window.partitionBy("id").orderBy("date")
df_md1 = df.withColumn("dense_rank", F.dense_rank().over(window_spec))
df_md1 = df_md1.filter(df["dense_rank"] == 2).drop("dense_rank")
df_md1.display()

# COMMAND ----------

# MAGIC %md
# MAGIC method-2

# COMMAND ----------

df_sorted = df.orderBy("date", ascending=[False])
df_sorted.display()

# COMMAND ----------

df_latest = df_sorted.dropDuplicates(["id"])
display(df_latest)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 12-08-2025

# COMMAND ----------

# MAGIC %md
# MAGIC How will you merge two files – File1 and File2 – into a single DataFrame if they have different schemas?

# COMMAND ----------

data1 = [
    ("Azarudeen, Shahul", 25),
    ("Michel, Clarke", 26),
    ("Virat, Kohli", 28),
    ("Andrew, Simond", 37)
]
df1 = spark.createDataFrame(data1, ["Name", "Age"])

# Second dataset
data2 = [
    ("Rabindra, Tagore", 32, "Male"),
    ("Madona, Laure", 59, "Female"),
    ("Flintoff, David", 12, "Male"),
    ("Ammie, James", 20, "Female")
]
df2 = spark.createDataFrame(data2, ["Name", "Age", "Gender"])

# COMMAND ----------

df1.write.mode("overwrite").option("header", True).csv("/Volumes/my_catalog/source/folder_managed_files/people_basic_csv")

# COMMAND ----------

df2.write.mode("overwrite").option("header",True).csv("/Volumes/my_catalog/default/sample")

# COMMAND ----------

df_read1 = spark.read.format("csv").option("header", True).load("/Volumes/my_catalog/source/folder_managed_files/people_basic_csv")
df_read1.display()
df_read2 = spark.read.format("csv").option("header", True).load("/Volumes/my_catalog/default/sample")
df_read2.display()


# COMMAND ----------

from pyspark.sql.functions import lit
from pyspark.sql.types import StringType
# Add missing column to df1
df_read1 = df_read1.withColumn("Gender", lit(None).cast(StringType()))

# COMMAND ----------

df_combined = df_read1.unionByName(df_read2, allowMissingColumns=True)

# COMMAND ----------

df_combined.display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Count the null value in each columns

# COMMAND ----------

import pyspark.sql.functions as F

# COMMAND ----------

data = [
    (1, "Alice", None),
    (2, None, 30),
    (3, "Charlie", None),
    (None, "David", 40)
]

df = spark.createDataFrame(data, ["id", "name", "age"])

null_counts = df.select([F.count(F.when(F.col(i).isNull(),i)).alias("null columns") for i in df.columns])
null_counts.display()

# COMMAND ----------

data = [
    (101, "Apple,Banana,Orange", 30),
    (102, "Mango,Peach", 20),
    (103,  "Grapes", 15)
]

df = spark.createDataFrame(data, ["order_id",  "items", "total_price"])

# Split items into an array and explode
df_normalized = (
    df
    .withColumn("item", F.explode(F.split(F.col("items"), ",")))
    .drop("items")
)

df_normalized.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 13/08/2025

# COMMAND ----------

# MAGIC %md
# MAGIC let assume we have duplicate records in our dataset based on particular key. we need to remove duplicate records but at the same time need to consider the maximum value of each column among duplicate values.

# COMMAND ----------

simpleData = (
    (100, "Mobile", 5000, 10),
    (100, "Mobile", 7000, 7),
    (200, "Laptop", 20000, 4),
    (200, "Laptop", 25000, 8),
    (200, "Laptop", 22000, 12)
)

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

defSchema = StructType([
    StructField("Product_id", IntegerType(), False),
    StructField("Product_name", StringType(), True),
    StructField("Price", IntegerType(), True),
    StructField("DiscountPercent", IntegerType(), True)
])

df = spark.createDataFrame(data=simpleData, schema=defSchema)
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC output like \
# MAGIC product_id || product_name || price || discountpercent \
# MAGIC 100            Mobile          7000     10 \
# MAGIC 200            Laptop          25000    12

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

# COMMAND ----------

window_spec = Window.partitionBy("product_id")
df = df.withColumn("max_price", max("price").over(window_spec)) \
        .withColumn("max_discount", max("discountPercent").over(window_spec))
df.display()
    

# COMMAND ----------

df_sel = df.select("Product_id","Product_name",col("max_price").alias("Price"), col("max_discount").alias("DiscountPercent"))

# COMMAND ----------

df_sel.distinct().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 14/8/2025

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark.sql.functions import col, lead, lag, when

spark = SparkSession.builder.getOrCreate()

# Input data
data = [
    (1, "A"),
    (2, "B"),
    (3, "C"),
    (4, "D"),
    (5, "E")
]
df = spark.createDataFrame(data, ["id", "student"])

w = Window.orderBy("id")

# Swap logic: odd rows take the next value, even rows take the previous value
df_swapped = df.withColumn(
    "student",
    when((col("id") % 2 != 0) & (lead("student").over(w).isNotNull()), lead("student").over(w))
    .when((col("id") % 2 == 0), lag("student").over(w))
    .otherwise(col("student"))
)

df_swapped.display()


# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

data = [
    ("ABCDE1234F",),  
    ("abcde1234f",),  
    ("ABCD12345F",),  
    ("ABCDE1234",),   
]
df = spark.createDataFrame(data, ["pan_number"])

# Regex pattern for PAN validation
pattern = "^[A-Z]{5}[0-9]{4}[A-Z]{1}$"

# Validate PAN numbers
df_validated = df.withColumn(
    "is_valid_pan",
    col("pan_number").rlike(pattern)
)

df_validated.show(truncate=False)
