# Databricks notebook source
data = [
    (1,"Alice",20,"CS",85),
    (2,"Bob",22,"IT",90),
    (3,"Charlie",20,'CS',92),
    (4,"David",22,"ME",76),
    (5,"Emma",21,"CS",88)    
]

df = spark.createDataFrame(data, ["id","name","age","course","marks"])

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window

# COMMAND ----------

window_spec = Window.partitionBy("course").orderBy("marks")

df_first = df.withColumn("first_mark", dense_rank().over(window_spec))
df_first.filter(df.first_mark == 1).display()