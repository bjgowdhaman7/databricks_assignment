# Databricks notebook source
# MAGIC %md
# MAGIC ## PySpark Window Function

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.window import Window
import pyspark.sql.functions as F

# COMMAND ----------

# MAGIC %md
# MAGIC ### Aggregate Functions in Window Context
# MAGIC
# MAGIC Aggregate functions such as sum, avg, min, and max can be applied over a defined window to perform operations like running totals or averages.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Use Cases
# MAGIC
# MAGIC Calculate Running Totals \
# MAGIC Compute cumulative sales for each category. \
# MAGIC Average sales for each category.

# COMMAND ----------

data = [
    ("Electronics", "Phone", 1000),
    ("Electronics", "Laptop", 1500),
    ("Electronics", "Tablet", 800),
    ("Furniture", "Chair", 300),
    ("Furniture", "Desk", 600),
    ("Furniture", "Table", 300)
]

# Create DataFrame
df = spark.createDataFrame(data, ["category", "product", "sales"])
df.display()

# COMMAND ----------

window_spec = Window.partitionBy("category").orderBy("product")

df_agg = df \
        .withColumn("cumulative_sales", sum("sales").over(window_spec)) \
        .withColumn("max_sales", max("sales").over(window_spec)) \
        .withColumn("average_sales", avg("sales").over(window_spec))

df_agg.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Ranking Functions
# MAGIC
# MAGIC Ranking functions are used to assign a rank or sequence to rows within a window partition.
# MAGIC
# MAGIC - rank() - 	Assigns a rank to each row, leaving gaps for ties -- Top sales performers per category per day
# MAGIC - dense_rank() -	Assigns a rank to each row without leaving gaps.
# MAGIC - row_number() -	Assigns a unique sequential number to each row.

# COMMAND ----------

window_spec = Window.partitionBy("category").orderBy("sales")

df_transformed = df \
    .withColumn("rank", rank().over(window_spec)) \
    .withColumn("dense_rank", dense_rank().over(window_spec)) \

df_transformed.orderBy(desc("category")).display()

# COMMAND ----------

# MAGIC %md
# MAGIC Data deduplication:
# MAGIC Removing duplicates by picking the first occurrence or latest record per group, row_number helps identify and filter those records.

# COMMAND ----------

data = [
    (1001, 1, 300, '2025-08-01'),
    (1001, 5, 320, '2025-08-02'),
    (1002, 1, 150, '2025-08-01'),
    (1002, 2, 150, '2025-08-01'),
    (1003, 1, 700, '2025-08-02')
]

df = spark.createDataFrame(data, ['transaction_id', 'store_id', 'sales_amount', 'transaction_date'])
df = df.withColumn('transaction_date', to_date('transaction_date'))

# Define window partition by transaction_id ordered by transaction_date descending (keep latest)
window_spec = Window.partitionBy('transaction_id').orderBy(col('transaction_date').desc())

df_with_rownum = df.withColumn('row_num', row_number().over(window_spec))
# df_with_rownum.display()
# Filter to keep only first row (latest record) per transaction_id
df_deduped = df_with_rownum.filter(col('row_num') == 1)

df_deduped.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Lead and Lag
# MAGIC Lead and lag functions are essential tools for analyzing sequential data, particularly in scenarios where comparisons between current, previous, and next rows are needed. \
# MAGIC These functions operate over windows and allow you to perform time-series analysis, trend detection, and other row-relative operations.

# COMMAND ----------

# MAGIC %md
# MAGIC ### lead(column, offset, default) 
# MAGIC - Fetches the value of a specified column from the next row within the same window.
# MAGIC
# MAGIC ### lag(column, offset, default)
# MAGIC
# MAGIC - Fetches the value of a specified column from the previous row within the same window.
# MAGIC
# MAGIC Parameters:
# MAGIC - column: Column to fetch the value from.
# MAGIC - offset: The number of rows to look ahead (default is 1).
# MAGIC - default: Value to return if the offset is out of bounds.
# MAGIC
# MAGIC Use Cases:
# MAGIC - Compare current and next values to identify growth or decline trends.
# MAGIC - Predict the next transaction or event for a user or entity.

# COMMAND ----------

data = [
    (1, "2024-01-01", 100,"browsing"),
    (1, "2024-01-03", 200,"browsing"),
    (1, "2024-01-02", 300,"carted"),
    (2, "2024-01-01", 50,"carted"),
    (2, "2024-01-02", 80,"carted"),
    (2, "2024-01-03", 120,"purchased"),
]

df = spark.createDataFrame(data, ["customer_id", "date", "amount","status"])
df.display()

# COMMAND ----------

window_spec = Window.partitionBy("customer_id").orderBy("date")

# COMMAND ----------

df = df \
    .withColumn("next transaction",  F.lead("amount", 1, 0).over(window_spec)) \
    .withColumn("previous transaction", F.lag("amount",1).over(window_spec))
    
df.select("customer_id", "date", "amount", "next transaction", "previous transaction").display()

# COMMAND ----------

# MAGIC %md
# MAGIC purchase difference

# COMMAND ----------

df = df.withColumn("purchase difference", F.col("amount") - F.lag("amount",1).over(window_spec))
df.select("customer_id", "date", "amount", "purchase difference").display()

# COMMAND ----------

# MAGIC %md
# MAGIC Status

# COMMAND ----------

df = df.withColumn("status_change", F.col("status") != F.lag("status", 1).over(window_spec))
df.select("customer_id","amount","status","status_change").display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### NTile 
# MAGIC The ntile function in PySpark is a window function that divides rows in a window partition into a specified number of approximately equal groups (or tiles). Each row is assigned a group number, starting from 1 up to the specified number of tiles.

# COMMAND ----------

data = [
    ("C1", 500),
    ("C2", 300),
    ("C3", 700),
    ("C4", 1000),
    ("C5", 200),
    ("C6", 800),
    ("C7", 400)
]
df = spark.createDataFrame(data, ["CustomerID", "Amount"])

win_spec = Window.orderBy(F.desc("Amount"))
 
df_result = df.withColumn("Quartile", F.ntile(4).over(win_spec))
df_result.display()

# COMMAND ----------

# MAGIC %md
# MAGIC How it works
# MAGIC 1. Divides rows into N groups(as equal as possible).
# MAGIC 2. Assigns group number from 1 -> N.
# MAGIC
# MAGIC If data size = 7 and N = 4: \
# MAGIC Group 1 - 2 records \
# MAGIC Group 2 - 2 records \
# MAGIC Group 3 - 2 records \
# MAGIC Group 4 - 1 records

# COMMAND ----------

# MAGIC %md
# MAGIC ### Row Between
# MAGIC
# MAGIC rowsBetween(start, end): This defines the range of rows to consider for each row.

# COMMAND ----------

# MAGIC %md
# MAGIC Parameters for ROWS BETWEEN:
# MAGIC
# MAGIC **start**: Defines where the window starts relative to the current row.
# MAGIC
# MAGIC - Window.unboundedPreceding: Starts from the first row. 
# MAGIC - X PRECEDING: Starts x rows before the current row. 
# MAGIC - Window.currentRow: Starts at the current row. 
# MAGIC
# MAGIC **end**: Defines where the window ends relative to the current row. 
# MAGIC
# MAGIC - Window.unboundedFollowing: Ends at the last row. 
# MAGIC - X FOLLOWING: Ends x rows after the current row. 
# MAGIC - Window.currentRow: Ends at the current row.
# MAGIC
# MAGIC The rowsBetween expects the start and end of the frame relative to the current row, where:
# MAGIC
# MAGIC - Negative numbers mean preceding rows
# MAGIC - Zero means current row
# MAGIC - Positive numbers mean following rows

# COMMAND ----------

# Sample data
data = [
    ("2024-01-01", "A", 100),
    ("2024-01-02", "A", 150),
    ("2024-01-03", "A", 200),
    ("2024-01-01", "B", 50),
    ("2024-01-02", "B", 75),
    ("2024-01-03", "B", 100)
]

# Create DataFrame
df = spark.createDataFrame(data, ["date", "category", "sales"])
df.display()

# COMMAND ----------

window_spec = Window.partitionBy("category").orderBy("date").rowsBetween(Window.unboundedPreceding, Window.currentRow)
df_cumulative_sum = df.withColumn("cumulative_sales", sum("sales").over(window_spec))
df_cumulative_sum.display()

# COMMAND ----------

from pyspark.sql.window import Window

# COMMAND ----------

window_spec = Window.partitionBy("category").orderBy("date").rowsBetween(-2, Window.currentRow)
df_moving = df_cumulative_sum.withColumn("cumulative_sales", sum("sales").over(window_spec))
df_moving.display()

# COMMAND ----------

window_spec = Window.partitionBy("category").orderBy("date").rowsBetween(-1, Window.currentRow)
df_moving = df_cumulative_sum.withColumn("cumulative_sales", sum("sales").over(window_spec))
df_moving.display()

# COMMAND ----------

# 3. Excluding Current & Future Rows
window_spec_excluding_future = Window.partitionBy("category").orderBy("date").rowsBetween(Window.unboundedPreceding, -1)
df_final = df.withColumn("cumulative_sales_excluding_curennt_n_future", sum("sales").over(window_spec_excluding_future))

df_final.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **percent_rank** - Based on rank positions. Equal scores share the same rank, so their percent_rank is equal. \
# MAGIC Formula:
# MAGIC
# MAGIC rank
# MAGIC −
# MAGIC 1 /
# MAGIC total_rows
# MAGIC −
# MAGIC 1
# MAGIC  
# MAGIC
# MAGIC **cume_dist** - Counts all rows up to the current row, including ties. \
# MAGIC Formula:
# MAGIC
# MAGIC number of rows with rank ≤ current row / 
# MAGIC total_rows
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC percent_rank() and cume_dist() are mainly used when you need to measure relative standing or distribution position of rows within a dataset — without collapsing the data like groupBy.

# COMMAND ----------

data = [
    ("A", 500),
    ("B", 400),
    ("C", 400),
    ("D", 300),
    ("E", 200)
]
df = spark.createDataFrame(data, ["employee", "score"])

# Window spec — order by score descending
w = Window.orderBy(col("score").desc())

df.withColumn("percent_rank", percent_rank().over(w)) \
  .withColumn("cume_dist", cume_dist().over(w)) \
  .display()