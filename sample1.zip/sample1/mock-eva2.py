# Databricks notebook source
def read_file(file_path, file_format):
    spark.read.format(file_format).load(file_path)



# COMMAND ----------

df1.join(broadcast(df2), df1.col == df2.col, how=inner)

# COMMAND ----------

createTempView(df1)

spark.sql("select * from df1").display()