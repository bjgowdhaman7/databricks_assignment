# Databricks notebook source
help(spark)

# COMMAND ----------

df = spark.createDataFrame([(1,),(2,)],["id"])
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC dbutils.fs.ls("/my_catalog.information_schema.catalog_privileges")

# COMMAND ----------

data = [
    (1, "Alice", 25),
    (2, "Bob", 30),
    (3, "Charlie", 35)
]

# Schema will be inferred automatically
df = spark.createDataFrame(data)

# COMMAND ----------

df.display()

# COMMAND ----------

data = [
    ('CULPE4829R',),
    ('PUDAD882E',),
    ('jdsid9999e',),
    ('UPDSFI9090P',),
    ('CULPQ0973U',)
]

pan_df = spark.createDataFrame(data, ["pan_number"])
pan_df.display()

# COMMAND ----------

from pyspark.sql.functions import *
import pyspark.sql.functions as F

# COMMAND ----------

check_valid_df = pan_df.withColumn("valid_pan", 
                                   F.when(F.col("pan_number").rlike("^[A-Z]{5}[0-9]{4}[A-Z]{1}$"),lit('Valid')).otherwise(lit('Invalid')))
check_valid_df.display()