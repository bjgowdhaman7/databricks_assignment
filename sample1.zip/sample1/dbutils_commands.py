# Databricks notebook source
dbutils.notebook.run("/Workspace/Users/gowdhaman.bj@diggibyte.com/sample1/project_notebook_1", timeout_seconds=60, arguments={"key": "value"})

# COMMAND ----------

result = dbutils.notebook.run("/Workspace/Users/gowdhaman.bj@diggibyte.com/sample1/project_notebook_1", 60, {"key": "value"})
print(result)  


# COMMAND ----------

dbutils.notebook.exit("Processing complete")


# COMMAND ----------

# See all available utilities
dbutils.help()

# COMMAND ----------

display(dbutils.fs.ls('/databricks-datasets'))

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.dropdown(
    name="env",               # The internal variable name for the widget
    defaultValue="qa",       # The default selected value
    choices=["qa", "dev", "prod"], # Available dropdown options
    label="Environment"       # The label shown in the UI
)


# COMMAND ----------

dbutils.widgets.get("env")

# COMMAND ----------

dbutils.widgets.removeAll() 

# COMMAND ----------

# MAGIC %md
# MAGIC combobox

# COMMAND ----------

dbutils.widgets.combobox(
    name="team",
    defaultValue="Data",
    choices=["Data", "ML", "Analytics"],
    label="Select Team"
)
env = dbutils.widgets.get("team")
print(f"Selected Environment: {env}")

# COMMAND ----------

# MAGIC %md
# MAGIC multiselect

# COMMAND ----------

dbutils.widgets.multiselect(
    name="regions",
    defaultValue="US",
    choices=["US", "EU", "APAC"],
    label="Regions"
)
regions = dbutils.widgets.get("regions")
print(f"Selected Regions: {regions}")

# COMMAND ----------

# MAGIC %md
# MAGIC text

# COMMAND ----------

dbutils.widgets.text(
    name="input_path",
    defaultValue="/mnt/data/raw",
    label="Data Path"
)


# COMMAND ----------

all_values = dbutils.widgets.getAll()
all_values

# COMMAND ----------

all_values

# COMMAND ----------

