# Databricks notebook source
from pyspark.sql.functions import *
import pyspark.sql.functions as F
from pyspark.sql.window import Window

# COMMAND ----------

data = [
    ("Electronics", "Phone", 1000),
    ("Electronics", "Laptop", 1500),
    ("Electronics", "Tablet", 800),
    ("Furniture", "Chair", 300),
    ("Furniture", "Desk", 600),
    ("Furniture", "Table", 300)
]

df = spark.createDataFrame(data, ["category", "product", "sales"])


# COMMAND ----------

window_spec = Window.partitionBy("category").orderBy(col("sales").desc())



df_trans = df.select("*",
                     sum("sales").over(window_spec).alias("cummulative_sum"),
                     rank().over(window_spec).alias("rank"),
                     dense_rank().over(window_spec).alias("dense_rank"))
display(df_trans)